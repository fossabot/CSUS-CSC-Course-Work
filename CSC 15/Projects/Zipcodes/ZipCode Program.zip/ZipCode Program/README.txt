Install:
-----------
1.) Copy and past zipcodes.txt to your desktop.
2.) Run the program.